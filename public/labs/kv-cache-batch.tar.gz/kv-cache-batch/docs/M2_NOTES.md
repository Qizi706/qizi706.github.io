# M2 学习工作表

这份工作表用于把 M2 拆成可以独立完成的小闭环。不要一次实现完整 MHA、GQA 和 KV Cache；每次只增加一个可以被测试否证的变换。

## M2-A1：只完成 Query Head 轴变换

### 学习契约

```text
Question: 怎样把扁平的 Head 特征拆成显式 Head 轴，并证明轴顺序正确？
Prediction:
Time box: 120 min
Action: 实现 split_heads(projected, num_heads)
Artifact: 一个函数、两个测试、本工作表中的预测与反思
Acceptance: Shape 和元素映射测试通过，关闭代码后能重新写出变换
Feedback source: unittest 失败信息与手算元素 Oracle
Result:
What changed:
Next decision:
```

### 1. 运行前预测

固定参数：

```text
B = 2
T = 5
H = 4
D_head = 3
```

先填写，不运行 NumPy：

```text
projected 输入 Shape = [__, __, __]
拆分 Head 后 Shape   = [__, __, __, __]
移动 Head 轴后 Shape = [__, __, __, __]
```

为每个轴写一句语义：

```text
B:
H:
T:
D_head:
```

选择一个坐标，例如 `b=1, h=2, t=3, d=1`，手算它在扁平投影最后一维中的索引：

```text
flat_index = ____________________
q[1, 2, 3, 1] 应等于 projected[__, __, __]
```

预测下面两步是否创建新数据 Buffer，并写出理由：

| 操作                  | View / Copy 预测 | 理由 | 实际结果 |
| --------------------- | ---------------- | ---- | -------- |
| 拆分最后一维          |                  |      |          |
| 交换 Head 与 Sequence |                  |      |          |

### 2. 只实现这个接口

在 `src/kv_cache_batch/multi_head.py` 中实现：

```python
def split_heads(projected: np.ndarray, num_heads: int) -> np.ndarray:
    """Convert [B, T, H * D_head] into [B, H, T, D_head]."""
    # TODO: validate the contract
    # TODO: split the final dimension
    # TODO: move the Head axis before Sequence
```

这一轮禁止加入：

- Q/K/V 权重投影；
- Softmax 与 Causal Mask；
- KV Cache；
- GQA Head 映射；
- 性能 Benchmark。

### 3. 两个最小测试

在 `tests/test_multi_head.py` 中只写：

1. **Shape 测试**：输入使用顺序值，检查输出为预测的四维 Shape。
2. **元素映射测试**：选择一个非零 `b/h/t/d`，用手算的 `flat_index` 比较变换前后的具体值。

Shape 测试只能证明尺寸正确；元素测试才用于排除 Head 与 Sequence 轴放反。

运行：

```bash
OPENBLAS_NUM_THREADS=1 \
OMP_NUM_THREADS=1 \
PYTHONPATH=src \
uv run python -m unittest discover -s tests -p 'test_multi_head.py' -v
```

### 4. 求助阶梯

只有上一层尝试 15 分钟仍无法推进时，才进入下一层：

1. 重新画出每一步 Shape，不看代码。
2. 回看 `examples/numpy_array_semantics.py` 中的 `swapaxes` Case。
3. 用 `B=1, T=2, H=2, D_head=2` 的顺序值数组手工追踪。
4. 向 AI 只询问“我的 Shape 推导哪一步不成立”，不索要完整实现。
5. 提交当前代码、失败输出和预测，请 AI Review 最小错误。

不要直接索要完整答案；独立能力来自“预测 → 失败 → 定位 → 修正”，不是来自第一次就写对。

### 5. 运行后记录

```text
实际 Shape:
元素映射是否成立:
内存共享观察:
第一次失败信息:
错误属于哪一层: 轴语义 / Shape 推导 / NumPy API / 测试设计
修正后的规则:
```

### 6. A1 验收

- [ ] 运行前预测已保存。
- [ ] Shape 测试通过。
- [ ] 非零坐标的元素映射测试通过。
- [ ] 能解释 `H * D_head` 为什么可以拆成两个轴。
- [ ] 能解释为什么仅检查 Shape 不足以证明轴顺序正确。
- [ ] 关闭代码后，能在空白文件中重新写出变换。

通过后进入 **M2-A2**：把同一变换迁移到 Q/K/V，并增加权重宽度与 Head 整除检查。未通过时只修正 A1，不扩展到 Attention。
